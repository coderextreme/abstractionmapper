java -classpath . -jar icbmc.jar John rmi://localhost/Generic_Room
