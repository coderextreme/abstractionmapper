#!/bin/bash
export CLASSPATH=.
rmiregistry
