java -classpath . -jar icbmc.jar Sara rmi://localhost/Generic_Room
